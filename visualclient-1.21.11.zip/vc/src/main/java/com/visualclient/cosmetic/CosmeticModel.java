package com.visualclient.cosmetic;

import net.minecraft.client.model.*;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;

/** Model kosmetik generik: tiap bagian (ModelPart) diberi nama, lalu digerakkan oleh feature renderer. */
public class CosmeticModel extends EntityModel<PlayerEntityRenderState> {
    public final ModelPart a, b; // a = kiri/kepala, b = kanan (opsional)

    public CosmeticModel(ModelPart root) {
        super(root);
        a = root.getChild("a");
        b = root.hasChild("b") ? root.getChild("b") : null;
    }

    private static ModelData data() { return new ModelData(); }

    /** Sayap: dua panel tipis, pivot di punggung. */
    public static TexturedModelData wings() {
        ModelData md = data(); ModelPartData r = md.getRoot();
        r.addChild("a", ModelPartBuilder.create().uv(0, 0).cuboid(0f, -6f, 0f, 14f, 18f, 1f), ModelTransform.origin(0f, 2f, 0f));
        r.addChild("b", ModelPartBuilder.create().uv(0, 0).mirrored().cuboid(-14f, -6f, 0f, 14f, 18f, 1f), ModelTransform.origin(0f, 2f, 0f));
        return TexturedModelData.of(md, 64, 64);
    }
    /** Topi: halo/mahkota datar di atas kepala. */
    public static TexturedModelData hat() {
        ModelData md = data(); ModelPartData r = md.getRoot();
        r.addChild("a", ModelPartBuilder.create().uv(0, 0).cuboid(-5f, -10.5f, -5f, 10f, 1.5f, 10f)
                                                  .uv(0, 20).cuboid(-1f, -13f, -1f, 2f, 3f, 2f), ModelTransform.NONE);
        return TexturedModelData.of(md, 64, 64);
    }
    /** Leggings: pelindung paha sedikit lebih besar dari kaki asli. */
    public static TexturedModelData legs() {
        ModelData md = data(); ModelPartData r = md.getRoot();
        r.addChild("a", ModelPartBuilder.create().uv(0, 0).cuboid(-2.3f, -0.3f, -2.3f, 4.6f, 7f, 4.6f), ModelTransform.NONE);
        r.addChild("b", ModelPartBuilder.create().uv(0, 0).cuboid(-2.3f, -0.3f, -2.3f, 4.6f, 7f, 4.6f), ModelTransform.NONE);
        return TexturedModelData.of(md, 64, 64);
    }
    /** Boots: bagian bawah kaki. */
    public static TexturedModelData boots() {
        ModelData md = data(); ModelPartData r = md.getRoot();
        r.addChild("a", ModelPartBuilder.create().uv(0, 0).cuboid(-2.4f, 7.2f, -2.8f, 4.8f, 5f, 5.6f), ModelTransform.NONE);
        r.addChild("b", ModelPartBuilder.create().uv(0, 0).cuboid(-2.4f, 7.2f, -2.8f, 4.8f, 5f, 5.6f), ModelTransform.NONE);
        return TexturedModelData.of(md, 64, 64);
    }
}

package com.visualclient.cosmetic;

import com.visualclient.Config;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.LivingEntityFeatureRendererRegistrationCallback;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRendererContext;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

import java.util.function.Supplier;

public class Cosmetics {
    enum Kind { WINGS, HAT, LEGS, BOOTS }
    private static EntityModelLayer layer(String n) { return new EntityModelLayer(Identifier.of("visualclient", n), "main"); }
    private static final EntityModelLayer WINGS = layer("wings"), HAT = layer("hat"), LEGS = layer("legs"), BOOTS = layer("boots");

    private static Identifier tex(String n) { return Identifier.of("visualclient", "textures/cosmetic/" + n + ".png"); }

    public static void init() {
        reg(WINGS, CosmeticModel::wings); reg(HAT, CosmeticModel::hat);
        reg(LEGS, CosmeticModel::legs);   reg(BOOTS, CosmeticModel::boots);

        LivingEntityFeatureRendererRegistrationCallback.EVENT.register((type, renderer, helper, ctx) -> {
            if (renderer instanceof PlayerEntityRenderer pr) {
                var ml = ctx.getEntityModels(); // LoadedEntityModels
                helper.register(new Layer(pr, new CosmeticModel(ml.getModelPart(WINGS)), tex("wings"), Kind.WINGS));
                helper.register(new Layer(pr, new CosmeticModel(ml.getModelPart(HAT)),   tex("hat"),   Kind.HAT));
                helper.register(new Layer(pr, new CosmeticModel(ml.getModelPart(LEGS)),  tex("legs"),  Kind.LEGS));
                helper.register(new Layer(pr, new CosmeticModel(ml.getModelPart(BOOTS)), tex("boots"), Kind.BOOTS));
            }
        });
    }
    private static void reg(EntityModelLayer l, Supplier<TexturedModelData> s) { EntityModelLayerRegistry.registerModelLayer(l, s::get); }

    static class Layer extends FeatureRenderer<PlayerEntityRenderState, PlayerEntityModel> {
        private final CosmeticModel model; private final Identifier texture; private final Kind kind;

        Layer(FeatureRendererContext<PlayerEntityRenderState, PlayerEntityModel> ctx, CosmeticModel m, Identifier t, Kind k) {
            super(ctx); model = m; texture = t; kind = k;
        }

        @Override
        public void render(MatrixStack matrices, OrderedRenderCommandQueue queue, int light,
                           PlayerEntityRenderState s, float limbAngle, float limbDistance) {
            boolean on = switch (kind) { case WINGS -> Config.wings; case HAT -> Config.hat;
                                         case LEGS -> Config.leggings; case BOOTS -> Config.boots; };
            if (!on || s.invisible) return;
            var mc = net.minecraft.client.MinecraftClient.getInstance();
            if (Config.quality == 0 && (mc.player == null || s.id != mc.player.getId())) return; // ringan: hanya diri sendiri
            PlayerEntityModel pm = getContextModel();
            int color = Config.theme.accent;            // kosmetik ikut warna tema
            int glow = LightmapTextureManager.MAX_LIGHT_COORDINATE; // menyala seperti fullbright, menyatu dgn efek

            matrices.push();
            switch (kind) {
                case WINGS -> {
                    matrices.translate(0f, 0f, 0.125f);
                    if (s.isInSneakingPose) matrices.translate(0f, 0.1f, 0.1f);
                    float flap = (float) Math.sin(s.age * 0.15f) * 0.12f + 0.35f + Math.min(1f, s.limbSwingAmplitude) * 0.3f;
                    model.a.yaw = flap; model.b.yaw = -flap;
                }
                case HAT -> { model.a.copyTransform(pm.head); }
                case LEGS, BOOTS -> { model.a.copyTransform(pm.leftLeg); model.b.copyTransform(pm.rightLeg); }
            }
            // Signature helper renderModel dari FeatureRenderer (1.21.9+); cek jika compile error
            renderModel(model, texture, matrices, queue, glow, s, color, 0);
            matrices.pop();
        }
    }
}

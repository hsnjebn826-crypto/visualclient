package com.visualclient.mixin;

import com.visualclient.Config;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.feature.ArmorFeatureRenderer;
import net.minecraft.client.render.entity.state.BipedEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** "Armor Blend": sembunyikan armor vanilla di leggings/boots agar kosmetik tampil menyatu (visual saja). */
@Mixin(ArmorFeatureRenderer.class)
public class ArmorHideMixin {
    @Inject(method = "render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;ILnet/minecraft/client/render/entity/state/BipedEntityRenderState;FF)V",
            at = @At("HEAD"), cancellable = true)
    private void visualclient$hide(MatrixStack m, OrderedRenderCommandQueue q, int l, BipedEntityRenderState s, float a, float b, CallbackInfo ci) {
        if (Config.armorBlend) ci.cancel();
    }
}

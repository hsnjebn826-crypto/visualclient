package com.visualclient.mixin;

import net.minecraft.client.option.SimpleOption;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

/** Membuka field 'value' agar gamma bisa > 1.0 (trik fullbright, hanya visual). */
@Mixin(SimpleOption.class)
public interface SimpleOptionAccessor<T> {
    @Mutable @Accessor("value") void visualclient$setValue(T value);
}

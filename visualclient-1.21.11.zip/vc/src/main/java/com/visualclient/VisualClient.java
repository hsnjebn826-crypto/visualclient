package com.visualclient;

import com.visualclient.mixin.SimpleOptionAccessor;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.util.InputUtil;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

public class VisualClient implements ClientModInitializer {
    private static KeyBinding menuKey;
    private boolean wasOnGround = true;
    private Double savedGamma = null;

    @Override public void onInitializeClient() {
        Config.load(); com.visualclient.cosmetic.Cosmetics.init();
        // Di 1.21.9+ KeyBinding memakai Category object
        KeyBinding.Category cat = KeyBinding.Category.create(Identifier.of("visualclient", "main"));
        menuKey = KeyBindingHelper.registerKeyBinding(
            new KeyBinding("key.visualclient.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, cat));
        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
    }

    private void tick(MinecraftClient mc) {
        while (menuKey.wasPressed()) mc.setScreen(new VisualMenuScreen());
        applyFullbright(mc);
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null) return;

        // Jump circle: cincin partikel saat lompat
        boolean jumped = wasOnGround && !p.isOnGround() && p.getVelocity().y > 0.1;
        if (Config.jumpCircle && jumped) {
            int n = new int[]{12, 24, 40}[Config.quality];
            for (int i = 0; i < n; i++) {
                double a = i / (double) n * Math.PI * 2;
                mc.world.addParticleClient(ParticleTypes.END_ROD, p.getX() + Math.cos(a) * 0.9, p.getY() + 0.05,
                    p.getZ() + Math.sin(a) * 0.9, Math.cos(a) * 0.04, 0.0, Math.sin(a) * 0.04);
            }
        }
        wasOnGround = p.isOnGround();

        // Trail: partikel di belakang pemain saat bergerak
        Vec3d v = p.getVelocity();
        int every = new int[]{4, 2, 1}[Config.quality];
        if (Config.trail && p.age % every == 0 && (v.x * v.x + v.z * v.z) > 0.002) {
            ParticleEffect fx = switch (Config.trailType) {
                case 1 -> ParticleTypes.GLOW; case 2 -> ParticleTypes.HEART; case 3 -> ParticleTypes.NOTE;
                default -> ParticleTypes.END_ROD; };
            mc.world.addParticleClient(fx, p.getX(), p.getY() + 0.1, p.getZ(), 0, 0.01, 0);
        }
    }

    /** Fullbright visual: naikkan gamma. Tidak mengubah apa pun di server. */
    @SuppressWarnings({"unchecked", "rawtypes"})
    private void applyFullbright(MinecraftClient mc) {
        var opt = mc.options.getGamma();
        if (Config.fullbright) {
            if (savedGamma == null) savedGamma = opt.getValue();
            ((SimpleOptionAccessor) (Object) opt).visualclient$setValue(15.0);
        } else if (savedGamma != null) {
            ((SimpleOptionAccessor) (Object) opt).visualclient$setValue(savedGamma);
            savedGamma = null;
        }
    }
}

package com.visualclient;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class VisualMenuScreen extends Screen {
    private static final String[] QUAL = {"Ringan", "Sedang", "Tinggi"};
    private static final String[] TRAILS = {"End Rod", "Glow", "Heart", "Note"};
    public VisualMenuScreen() { super(Text.literal("Visual Client")); }

    @Override protected void init() {
        rebuild();
    }

    private void rebuild() {
        clearChildren();
        int w = 170, h = 20, gap = 24, x = width / 2 - w - 5, y = height / 2 - 70;
        // Kolom kiri: efek
        add(x, y,           w, h, "Tema: " + Config.theme.label, () -> Config.theme = Config.theme.next());
        add(x, y + gap,     w, h, tog("Fullbright", Config.fullbright), () -> Config.fullbright = !Config.fullbright);
        add(x, y + gap * 2, w, h, tog("Jump Circle", Config.jumpCircle), () -> Config.jumpCircle = !Config.jumpCircle);
        add(x, y + gap * 3, w, h, tog("Trail", Config.trail), () -> Config.trail = !Config.trail);
        add(x, y + gap * 4, w, h, "Jenis Trail: " + TRAILS[Config.trailType], () -> Config.trailType = (Config.trailType + 1) % TRAILS.length);
        // Kolom kanan: kosmetik (fase 2)
        int x2 = width / 2 + 5;
        add(x2, y,           w, h, tog("Topi / Kepala", Config.hat), () -> Config.hat = !Config.hat);
        add(x2, y + gap,     w, h, tog("Wings", Config.wings), () -> Config.wings = !Config.wings);
        add(x2, y + gap * 2, w, h, tog("Leggings", Config.leggings), () -> Config.leggings = !Config.leggings);
        add(x2, y + gap * 3, w, h, tog("Boots", Config.boots), () -> Config.boots = !Config.boots);
        add(x2, y + gap * 4, w, h, tog("Armor Blend", Config.armorBlend), () -> Config.armorBlend = !Config.armorBlend);
        add(x, y + gap * 5 + 6, w, h, "Kualitas: " + QUAL[Config.quality], () -> Config.quality = (Config.quality + 1) % 3);
        add(x2, y + gap * 5 + 6, w, h, "Selesai", this::close);
    }

    private String tog(String n, boolean v) { return n + ": " + (v ? "ON" : "OFF"); }

    private void add(int x, int y, int w, int h, String label, Runnable r) {
        addDrawableChild(ButtonWidget.builder(Text.literal(label), b -> {
            r.run(); Config.save(); rebuild();
        }).dimensions(x, y, w, h).build());
    }

    @Override public void render(DrawContext ctx, int mx, int my, float delta) {
        Theme t = Config.theme;
        ctx.fillGradient(0, 0, width, height, t.bgTop, t.bgBottom);
        int pw = 370, px = width / 2 - pw / 2, py = height / 2 - 100;
        ctx.fill(px, py, px + pw, py + 3, t.accent); // garis aksen
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("VISUAL CLIENT"), width / 2, py + 12, t.accent);
        ctx.drawTextWithShadow(textRenderer, Text.literal("Efek"), width / 2 - 175, height / 2 - 82, t.text);
        ctx.drawTextWithShadow(textRenderer, Text.literal("Kosmetik"), width / 2 + 5, height / 2 - 82, t.text);
        super.render(ctx, mx, my, delta);
    }

    @Override public void renderBackground(DrawContext ctx, int mx, int my, float delta) { /* pakai gradient sendiri */ }
    @Override public boolean shouldPause() { return false; }
}

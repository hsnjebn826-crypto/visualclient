package com.visualclient;

/** Tema UI. Tambah tema baru cukup tambah satu baris. Warna format 0xAARRGGBB. */
public enum Theme {
    BLUE ("Biru",         0xE0081428, 0xE01B3A6B, 0xFF4DA3FF, 0xFFFFFFFF),
    SPACE("Luar Angkasa", 0xE0050010, 0xE02A0A4A, 0xFFB47CFF, 0xFFE8D9FF),
    SUNSET("Sunset",      0xE02A0A14, 0xE06B1B3A, 0xFFFF8A5C, 0xFFFFE4D6),
    MINT ("Mint",         0xE0061E1A, 0xE0125A4C, 0xFF4DFFC3, 0xFFE0FFF5);

    public final String label; public final int bgTop, bgBottom, accent, text;
    Theme(String l, int t, int b, int a, int tx) { label = l; bgTop = t; bgBottom = b; accent = a; text = tx; }
    public Theme next() { return values()[(ordinal() + 1) % values().length]; }
}

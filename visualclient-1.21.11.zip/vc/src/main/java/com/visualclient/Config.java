package com.visualclient;

import com.google.gson.*;
import net.fabricmc.loader.api.FabricLoader;
import java.nio.file.*;

public class Config {
    public static Theme theme = Theme.BLUE;
    public static boolean fullbright = false, jumpCircle = true, trail = true;
    public static boolean hat = false, wings = false, leggings = false, boots = false; // fase 2 (render kosmetik)
    public static boolean armorBlend = false;                                          // fase 2
    public static int quality = 0; // 0 Ringan, 1 Sedang, 2 Tinggi (default ringan utk HP)
    public static int trailType = 0; // 0 end_rod, 1 glow, 2 heart, 3 note
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("visualclient.json");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public static void save() {
        JsonObject o = new JsonObject();
        o.addProperty("theme", theme.name()); o.addProperty("fullbright", fullbright);
        o.addProperty("jumpCircle", jumpCircle); o.addProperty("trail", trail); o.addProperty("trailType", trailType); o.addProperty("quality", quality);
        o.addProperty("hat", hat); o.addProperty("wings", wings); o.addProperty("leggings", leggings);
        o.addProperty("boots", boots); o.addProperty("armorBlend", armorBlend);
        try { Files.writeString(FILE, GSON.toJson(o)); } catch (Exception ignored) {}
    }
    public static void load() {
        try {
            if (!Files.exists(FILE)) return;
            JsonObject o = JsonParser.parseString(Files.readString(FILE)).getAsJsonObject();
            theme = Theme.valueOf(o.get("theme").getAsString());
            fullbright = o.get("fullbright").getAsBoolean(); jumpCircle = o.get("jumpCircle").getAsBoolean();
            trail = o.get("trail").getAsBoolean(); trailType = o.get("trailType").getAsInt();
            hat = o.get("hat").getAsBoolean(); wings = o.get("wings").getAsBoolean();
            leggings = o.get("leggings").getAsBoolean(); boots = o.get("boots").getAsBoolean();
            armorBlend = o.get("armorBlend").getAsBoolean(); quality = o.get("quality").getAsInt();
        } catch (Exception ignored) {}
    }
}
